#include <iostream>
#include "sts.h"

using namespace std;

int main()
{
    vuz n1;
    n1.m_a();
    n1.menu();
    return 0;
}
