#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <climits>

using namespace std;

class vuz
{
public:


int m_a()
{
int n;
ofstream beg("ss.txt", ios_base::trunc);
beg.close();
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0 || n > 20)
{
m_a();
}

for (int i = 1; i <= n; i++)
{
gen_name();
vars();
}
}


void menu()
{

system("clear");
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Список всех ВУЗов" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
system("clear");
menu_2();
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
system("clear");
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu();
}

}


void menu_2()
{
ifstream fin("ss.txt");
ofstream fout("ss.txt", ios_base::app);
char ch2;
cout << "Введите\n'a' -- для вывода всего списка\n'b' -- для поиска ВУЗов по порядковому номеру\n'c' -- для поиска ВУЗов по количеству студентов\n" << endl;
cin >> ch2;

if (ch2 == 'a')
{
system("clear");
out();
}
else if (ch2 == 'b')
{
system("clear");
ifstream fin("ss.txt");
int l;
string line;
cout << "Введите порядковый номер ВУЗа ";
cin >> l;

for (int i = 8 * l; i < 8 * (l + 1); i++)
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}

else if (ch2 == 'c')
{
system("clear");
int l;
string v,line;
cout << "Введите количество студентов в ВУЗе ";
cin >> v;
v = "Количество студентов в ВУЗе " + v;

while (!fin.eof())
{
getline(fin,line);
l++;
if (line == v)
{
for (int i = (l - 2); i <= (l+5); i++)
{
getline (fin,line);
cout << line << endl;
}
}
}
}

}



void gen_name()
{

string nam,nam2;
ofstream fout("ss.txt", ios_base::app);
ifstream fin("n.txt");

for (int i = 0; i <= (rand() % 7 + 3); i++)
{

for (int i = 1; i <= (rand() % 25 + 1); i++)
{
getline(fin,nam);
}
nam2 = nam2 + nam;
}

fout << "Название " << nam2 << endl;
fout.close();
}

void vars()
{
bool b = false;
int cou,gs,caf2;
string caf;
ofstream fout("ss.txt", ios_base::app);
ifstream fin("caf.txt");
cou = rand() % 5 + 3;
fout << "Количество курсов " << cou << endl;

caf2 = rand() % 10 + 1;
for (int i = 1; i <= caf2; i++)
{
getline(fin,caf);
}
fout << "Количество кафедр " << caf << endl;

while (b == false)
{

gs = rand()  % 20 + 1;
if ((gs % cou) == 0)
{
fout << "Количество групп " << gs << endl;
b = true;
}
}

int sts;
int s_sts = 0;

for (int i=1; i <= gs; i++)
{
sts = rand() % 35 + 25;
s_sts = s_sts + sts;
}

fout << "Количество студентов на кафедре " << s_sts << endl;
fout << "Количество студентов в ВУЗе " << s_sts * caf2 << endl;
fout << "\n" << endl;
fout.close();
fin.close();
}


void out()
{
system("clear");
string line;
ifstream fin("ss.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu();
}
else
valid();
}

};
