#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>

using namespace std;

class an
{
public:

int n,s;

int m_a(int &n)
{
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0)
{
m_a(n);
}
else if (n>20)
{
m_a(n);
}
return n;
}

void menu(int n)
{
system("clear");
ofstream beg("ans.txt", ios_base::trunc);
beg.close();
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Создать список котов" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
pos(s);
for (int i = 1; i <= n; i++)
{
vars(s);
}
out();
cout << "\n" << endl;
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu(n);
}

}

void pos(int &s)
{
system("clear");
cout << "Введите порог массы ";
cin >> s;
}

void vars(int n)
{
system("clear");
string name,p,lname;
int m,a;
ofstream fout("ans.txt", ios_base::app);
cout << "Введите имя кота ";
cin >> name ;
cout << "Введите породу ";
cin >> p;
cout << "Введите возраст ";
cin >> a;
cout << "Введите массу ";
cin >> m;
cout << "Введите фамилию хозяина ";
cin >> lname ;
if (m <= s)
{
fout << name << endl;
fout.close();
}
}

void out()
{
int i = 0;
system("clear");
string line;
ifstream fin("ans.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
i++;
}
cout << "Количество котов: " << i - 1 << endl;
fin.close();
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu(n);
}
else
valid();
}

};
