#include <iostream>
#include "sms.h"

using namespace std;

int main()
{
    smart n1;
    n1.m_a();
    n1.menu();
    return 0;
}
