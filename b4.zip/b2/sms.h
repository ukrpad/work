#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <climits>

using namespace std;

class smart
{
public:


int m_a()
{
int n;
ofstream beg("ps.txt", ios_base::trunc);
beg.close();
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0 || n > 20)
{
m_a();
}

for (int i = 1; i <= n; i++)
{
gen_name();
vars();
cam();
}
}


void menu()
{

system("clear");
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Список всех смартфонов" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
system("clear");
menu_2();
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
system("clear");
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu();
}

}


void menu_2()
{
ifstream fin("ps.txt");
ofstream fout("ps.txt", ios_base::app);
char ch2;
cout << "Введите\n'a' -- для вывода всего списка\n'b' -- для поиска смартфонов по порядковому номеру\n'c' -- для поиска смартфона по размеру экрана\n" << endl;
cin >> ch2;

if (ch2 == 'a')
{
system("clear");
out();
}
else if (ch2 == 'b')
{
system("clear");
ifstream fin("ps.txt");
int l;
string line;
cout << "Введите порядковый номер смартфона ";
cin >> l;
for (int i = 8 * l; i < 8 * (l + 1); i++)
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}
else if (ch2 == 'c')
{
system("clear");
int l;
string v,line;
cout << "Введите размер экрана (в дюймах) ";
cin >> v;
v = "Размер экрана " + v + " дюйм";

while (!fin.eof())
{
getline(fin,line);
l++;
if (line == v)
{
for (int i = (l - 2); i <= (l+5); i++)
{
getline (fin,line);
cout << line << endl;
}
}
}
}
}



void gen_name()
{
string nam;
int l = rand() % 20 + 1;
string buf;
ofstream fout("ps.txt", ios_base::app);
ifstream in("mod.txt");
for (int i = 1; i <= l; i++)
{
getline(in,buf);
}
nam = buf;
fout << "Производитель " << nam << endl;
in.close();
fout.close();
}

void vars()
{
int ram,rom,cor,s1,s2,v1,v2;
ofstream fout("ps.txt", ios_base::app);
int m0[3] = {3,4,5};
int m1[2] = {9,0};
int m2[6] = {0,1,2,3,4,5};
int cor_mas[5] = {1,2,4,6,8};
int m3[2] = {1,2};
cor = cor_mas[rand() % 5];
ram = rand() % 3 + 1;
rom = rand() % 4 + 128;
s1 = m0[rand() % 3];
if (s1 == 3)
{
s2 = m1[rand() % 2];
fout << "Размер экрана " << s1 << "." << s2 << " дюйм" << endl;
}
else if (s1 == 4)
{
s2 = rand() % 10;
fout << "Размер экрана " << s1 << "." << s2 << " дюйм" << endl;
}
else if (s1 == 5)
{
s2 = m2[rand() % 6];
fout << "Размер экрана " << s1 << "." << s2 << " дюйм" << endl;
}

v1 = m3[rand() % 2];
if (v1 == 1)
{
v2 = rand() % 10;
fout << "Процессор " << s1 << "." << s2 << " ГГц" << endl;
}
else if (v1 == 2)
{
v2 = m2[rand() % 6];
fout << "Процессор " << s1 << "." << s2 << " ГГц" << endl;
}
fout << "Количество ядер " << cor << endl;
fout << "ОЗУ " << ram << endl;
fout << "ПЗУ " << rom << endl;
fout.close();
}

void cam()
{
int line;
int m1[6] = {1,2,5,8,12,16};
line = m1[rand() % 6];
ofstream fout("ps.txt", ios_base::app);
fout << "Камера " << line << " Мп" << endl;
fout << "\n" << endl;
fout.close();
}

void out()
{
system("clear");
string line;
ifstream fin("ps.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu();
}
else
valid();
}

};
