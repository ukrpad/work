#include <iostream>
#include "match.h"

using namespace std;

int main()
{
    match n1;
    n1.m_a();
    n1.menu();
    return 0;
}
