#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <vector>
#include <unistd.h>
#include <climits>

using namespace std;

class match
{
public:

int s,sc;


int m_a()
{
int n;
ofstream beg("matches.txt", ios_base::trunc);
beg.close();
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0 || n > 20)
{
m_a();
}

s = 0;
for (int i = 1; i <= n; i++)
{
vars(sc);
sum(sc,s);
}
}


void menu()
{

system("clear");
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Список всех матчей" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
system("clear");
menu_2();
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
system("clear");
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu();
}

}


void menu_2()
{
ifstream fin("matches.txt");
ofstream fout("matches.txt", ios_base::app);
char ch2;
cout << "Введите\n'a' -- для вывода всего списка\n'b' -- для поиска матчей по порядковому номеру\n" << endl;
cin >> ch2;

if (ch2 == 'a')
{
system("clear");
out(s);
}
else if (ch2 == 'b')
{
system("clear");
ifstream fin("matches.txt");
int l;
string line;
cout << "Введите порядковый номер матча ";
cin >> l;
for (int i = 12 * l; i < 12 * (l + 1); i++)
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}


}



void vars(int &sc)
{
string nam;
string buf1,buf2;
ofstream fout("matches.txt", ios_base::app);
ifstream in("mod.txt");
for (int i = 1; i <= (rand() % 20 + 1); i++)
{
getline(in,buf1);
}
nam = buf1;
fout << "Команда " << nam << endl;
for (int i = 1; i <= (rand() % 20 + 1); i++)
{
getline(in,buf2);
}
nam = buf2;
fout << "Команда " << nam << endl;
in.close();
int sc1,sc2,min,i;

sc1 = rand() % 4;
fout << "Количество забитых голов " << sc1 << endl;

vector<int> goal(sc1);

if (sc1 == 1)
{
goal[0] = rand() % 120 + 1;
fout << "Гол был забит на " << goal[0] << " минуте" << endl;
}

if (sc1 == 2)
{
int m1 = rand() % 120 + 1;
int m2 = rand() % 120 + 1;
int m;

if (m1 > m2)
{
m = m1;
m1 = m2;
m2 = m;
}

goal[0] = m1;
goal[1] = m2;

fout << "Гол был забит на " << goal[0] << " минуте" << endl;
fout << "Гол был забит на " << goal[1] << " минуте" << endl;

}

else if (sc1 == 3)
{
int m1 = rand() % 120 + 1;
int m2 = rand() % 120 + 1;
int m3 = rand() % 120 + 1;
int m;

if (m1 > m2)
{
m = m1;
m1 = m2;
m2 = m;
}

if (m1 > m3)
{
m = m1;
m1 = m3;
m3 = m;
}

if (m2 > m3)
{
m = m2;
m2 = m3;
m3 = m;
}

goal[0] = m1;
goal[1] = m2;
goal[2] = m3;

fout << "Гол был забит на " << goal[0] << " минуте" << endl;
fout << "Гол был забит на " << goal[1] << " минуте" << endl;
fout << "Гол был забит на " << goal[2] << " минуте" << endl;

}
sc2 = rand() % 4;
fout << "Количество забитых голов " << sc2 << endl;

sc = sc1 + sc2;

vector<int> goal1(sc2);

if (sc2 == 1)
{
goal1[0] = rand() % 120 + 1;
fout << "Гол был забит на " << goal1[0] << " минуте" << endl;
}

if (sc2 == 2)
{
int m1 = rand() % 120 + 1;
int m2 = rand() % 120 + 1;
int m;

if (m1 > m2)
{
m = m1;
m1 = m2;
m2 = m;
}

goal1[0] = m1;
goal1[1] = m2;

fout << "Гол был забит на " << goal1[0] << " минуте" << endl;
fout << "Гол был забит на " << goal1[1] << " минуте" << endl;

}

else if (sc2 == 3)
{
int m1 = rand() % 120 + 1;
int m2 = rand() % 120 + 1;
int m3 = rand() % 120 + 1;
int m;

if (m1 > m2)
{
m = m1;
m1 = m2;
m2 = m;
}

if (m1 > m3)
{
m = m1;
m1 = m3;
m3 = m;
}

if (m2 > m3)
{
m = m2;
m2 = m3;
m3 = m;
}

goal1[0] = m1;
goal1[1] = m2;
goal1[2] = m3;

fout << "Гол был забит на " << goal1[0] << " минуте" << endl;
fout << "Гол был забит на " << goal1[1] << " минуте" << endl;
fout << "Гол был забит на " << goal1[2] << " минуте" << endl;

}

if (sc1 > sc2)
{
fout << "Победитель " << buf1 << endl;
}
if (sc1 < sc2)
{
fout << "Победитель " << buf2 << endl;
}
if (sc1 == sc2)
{
fout << "Ничья" << endl;
}


fout << "\n" << endl;
fout << "\n" << endl;
fout << "\n" << endl;
fout << "\n" << endl;
fout << "\n" << endl;
fout << "\n" << endl;
fout << "\n" << endl;
fout.close();
}

int sum(int sc,int &s)
{
s = s + sc;
return s;
}

void out(int s)
{
system("clear");
string line;
ifstream fin("matches.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
}
cout << s << endl;
fin.close();
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu();
}
else
valid();
}

};
