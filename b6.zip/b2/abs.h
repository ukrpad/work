#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>

using namespace std;

class abs
{
public:

int n;

int m_a(int &n)
{
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0)
{
m_a(n);
}
else if (n>20)
{
m_a(n);
}
return n;
}

void menu(int n)
{
system("clear");
ofstream beg("abs.txt", ios_base::trunc);
beg.close();
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Создать список абитуриентов" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
for (int i = 1; i <= n; i++)
{
vars();
}
out();
cout << "\n" << endl;
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu(n);
}

}


void vars()
{
system("clear");
string name,uname,lname,adr,city;
int s1,s2,s3,s4;
float s = 9.5;
ofstream fout("abs.txt", ios_base::app);
cout << "Введите имя ";
cin >> name ;
cout << "Введите фамилию ";
cin >> uname ;
cout << "Введите отчество ";
cin >> lname ;
cout << "Введите название улицы ";
cin >> adr ;
cout << "Введите город ";
cin >> city ;
cout << "Введите оценку за первый экзамен ";
cin >> s1 ;
cout << "Введите оценку за второй экзамен ";
cin >> s2 ;
cout << "Введите оценку за третий экзамен ";
cin >> s3 ;
cout << "Введите оценку за четвертый экзамен ";
cin >> s4 ;
if ((((s1+s2+s3+s4)/4) >= s) && (city == "Харьков"))
{
fout << uname << endl;
fout.close();
}
}

void out()
{
int i = 0;
system("clear");
string line;
ifstream fin("abs.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
i++;
}
cout << "Количество абитуриентов: " << i - 1 << endl;
fin.close();
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu(n);
}
else
valid();
}

};
