#include <iostream>
#include "abs.h"

using namespace std;

int main()
{
    int n;
    abs n1;
    n1.m_a(n);
    n1.menu(n);
    return 0;
}
