#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <vector>
#include <cmath>
#include <climits>

using namespace std;

class number
{
public:

int n,g_m,l_p,m;
bool life;

int m_a(int &n)
{
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0)
{
m_a(n);
}
else if (n>20)
{
m_a(n);
}
return n;
}

void menu(int n, int g_m, int l_p)
{
system("clear");
ofstream beg("plans.txt", ios_base::trunc);
beg.close();
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Список планет" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
system("clear");
for (int i = 1; i <= n; i++)
{
gen_name();
gen_var(life);
mass(m);
dmy();
wr(g_m,m,life,l_p);
}
out();
cout << "Общая масса планет " << g_m << endl;
cout << "Количество обитаемых планет " << l_p << endl;
cout << "\n" << endl;
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
system("clear");
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu(n,g_m,l_p);
}

}


void gen_name()
{
int l = rand() % 20 + 1;
string buf;
ifstream in("names.txt");
for (int i = 1; i <= l; i++)
{
getline(in,buf);
}
ofstream fout("plans.txt", ios_base::app);
fout << buf << endl;
fout.close();
in.close();
}

void mass(int &m)
{
m = rand() % INT_MAX;
if (m <= 0)
{
mass(m);
}
else if (m>0)
{
ofstream fout("plans.txt", ios_base::app);
fout << "Масса " << m << " кг" << endl;
fout.close();
}
}

void gen_var(bool &life)
{
int far,r;
bool wat;
float grav,k;

wat = rand() % INT_MAX;
far = rand() % INT_MAX;
r = rand() % INT_MAX;
ofstream fout("plans.txt", ios_base::app);
if (wat == true)
{
fout << "Вода на планете есть" << endl;
}
else if (wat == false)
{
fout << "Воды на планете нет" << endl;
}
grav = 6.67 * pow(10,-11) * m / pow(r,2);

k = 149000000/far;


fout << "Размер планеты " << 2 * r << " тыс. км" << endl;
fout << "Уровень гравитации на планете " << grav << " Ньютон" << endl;

if (wat == true && (6371/r) == k && (grav >= 9.5 && grav >= 10.5))
{
fout << "Жизнь на планете возможна" << endl;
life = true;
}
else if (wat == false)
{
fout << "Жизни на планете нет" << endl;
life = false;
}
fout.close();
}

void dmy()
{
int day,month,year;
day = rand() % INT_MAX;
month = day * 30;
year = month * 12;
ofstream fout("plans.txt", ios_base::app);
fout << "Длительность дня " << day << " секунд" << endl;
fout << "Длительность месяца " << month << "  секунд" << endl;
fout << "Длительность года " << year << " секунд" << endl;
fout << "\n" << endl;
fout.close();
}


void out()
{
system("clear");
string line;
ifstream fin("plans.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}

int wr(int &g_m, int m, int life, int &l_p)
{
g_m = g_m + m;
if (life == true)
{
l_p = l_p + 1;
}
return g_m;
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu(n,g_m,l_p);
}
else
valid();
}

};
