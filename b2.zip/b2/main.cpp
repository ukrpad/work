#include <iostream>
#include "plan.h"

using namespace std;

int main()
{
    int n,g_m,l_p;
    number n1;
    n1.m_a(n);
    n1.menu(n,g_m,l_p);
    n1.gen_name();
    return 0;
}
