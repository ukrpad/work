#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>

using namespace std;

class number
{
public:

int n,sum,f_sum;

int m_a(int &n)
{
system("clear");
cout << "Введите количество экземпляров класса (не более 20): ";
cin >> n;
if (n <= 0)
{
m_a(n);
}
else if (n>20)
{
m_a(n);
}
return n;
}

void menu(int n, int sum, int f_sum)
{
system("clear");
ofstream beg("nums.txt", ios_base::trunc);
beg.close();
cout << "Выберите вариант для продолжения:" << endl;
cout << "\n" << endl;
cout << "1. Показать список номеров" << endl;
cout << "2. Об авторе" << endl;
cout << "3. Выйти" << endl;
cout << "\n" << endl;

int ch;
cin >> ch;

switch (ch)
{
case 1:
for (int i = 1; i <= n; i++)
{
gen_num(sum);
gen_name();
wr(sum,f_sum);
}
out();
cout << "Сумма всех цифр " << f_sum << endl;
cout << "\n" << endl;
valid();
break;

case 2:
system("clear");
cout << ""/*Тут что-то от себя напишешь*/ << endl;
cout << "\n" << endl;
valid();
break;

case 3:
exit;
break;

default:
cout << "\n" << endl;
cerr << "Ошибка!" << endl;
sleep(3);
menu(n,sum,f_sum);
}

}

int gen_num(int &sum)
{

int oper[12] = {39,50,63,66,67,68,93,95,96,97,98,99};
int xxx = rand() % 101+899;
int o = oper[rand() % 12];
sum = 0;
int s1 = 0;
int s2 = 0;
int s3 = 0;
for (int i = 1; i<=4; i++)
{
ofstream fout("buff.txt", ios_base::app);
int a = rand() % 10;
fout << a;
fout.close();
s3 = s3 + a;
}


char buffer[2];
ifstream fin("buff.txt");
fin >> buffer;
fin.close();
remove("buff.txt");
ofstream fout("nums.txt", ios_base::app);
fout << "0" << o;
fout << xxx;
fout << buffer <<endl;

switch (o)
{
case 39:
fout << "Київстар" << endl;
fout.close();
break;
case 67:
fout << "Київстар" << endl;
fout.close();
break;
case 68:
fout << "Київстар" << endl;
fout.close();
break;
case 96:
fout << "Київстар" << endl;
fout.close();
break;
case 97:
fout << "Київстар" << endl;
fout.close();
break;
case 98:
fout << "Київстар" << endl;
fout.close();
break;
case 50:
fout << "МТС" << endl;
fout.close();
break;
case 66:
fout << "МТС" << endl;
fout.close();
break;
case 95:
fout << "МТС" << endl;
fout.close();
break;
case 99:
fout << "МТС" << endl;
fout.close();
break;
case 63:
fout << "Life" << endl;
fout.close();
break;
case 93:
fout << "Life" << endl;
fout.close();
break;
}

while(o)
{ int m=o;
m %= 10;
s1 += m;
o /= 10;
}

while(xxx)
{ int m=xxx;
m %= 10;
s2 += m;
xxx /= 10;
}

sum = s1 + s2 + s3;

ofstream file("nums.txt", ios_base::app);
file << "Сумма цифр номера: " << sum << endl;
file.close();

s1 = 0;
s2 = 0;
s3 = 0;
o = 0;
xxx = 0;
return sum;
}

void gen_name()
{

string base[20] = {"Адольф", "Бенедикт", "Гаврил", "Денис", "Захар", "Леонид", "Руслан", "Абрам", "Петр", "Олег", "Максим", "Фридерик", "Константин", "Александр", "Владимир", "Антон", "Борис", "Морис", "Вадим", "Михаил"};
string name = base[rand() % 20];
string uname = base[rand() % 20]+"ов";
string lname = base[rand() % 20]+"ович";
ofstream fout("nums.txt", ios_base::app);
fout << uname << " " << name << " " << lname << endl;
fout << "\n";
fout.close();

}

void out()
{
system("clear");
string line;
ifstream fin("nums.txt");
while (!fin.eof())
{
getline (fin,line);
cout << line << endl;
}
fin.close();
}

int wr(int sum, int &f_sum)
{
f_sum = f_sum + sum;
return f_sum;
}

void valid()
{
char ch_back;
cout << "Введите 'b' для того, чтобы выйти в главное меню" << endl;
cout << "\n" << endl;
cin >> ch_back;
if (ch_back == 'b')
{
menu(n,sum,f_sum);
}
else
valid();
}

};
