#include <iostream>
#include "num.h"

using namespace std;

int main()
{
    int n,sum,f_sum;
    number n1;
    n1.m_a(n);
    n1.menu(n,sum,f_sum);
    n1.gen_num(sum);
    n1.gen_name();
    return 0;
}
